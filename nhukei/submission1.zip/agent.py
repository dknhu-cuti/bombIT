import random
from collections import deque


class Agent:
    team_id = "NhukeiAgent"
    MOVES = {
        0: (0, 0),
        1: (-1, 0),
        2: (1, 0),
        3: (0, -1),
        4: (0, 1),
    }

    def __init__(self, agent_id: int):
        self.agent_id = int(agent_id)
        self.memo = {}

    def act(self, obs):
        grid = obs["map"]
        players = obs["players"]
        bombs = obs["bombs"]

        if self.agent_id >= len(players) or players[self.agent_id][2] != 1:
            return 0

        my_x, my_y, _, bombs_left, bomb_bonus = players[self.agent_id]
        my_pos = (int(my_x), int(my_y))
        bomb_radius = max(1, int(bomb_bonus) + 1)

        enemies = [
            (int(p[0]), int(p[1]))
            for i, p in enumerate(players)
            if i != self.agent_id and p[2] == 1
        ]
        occupied = {
            (int(p[0]), int(p[1]))
            for i, p in enumerate(players)
            if i != self.agent_id and p[2] == 1
        }
        bomb_positions = {(int(b[0]), int(b[1])) for b in bombs}
        blocked = set(occupied) | bomb_positions
        blocked.discard(my_pos)

        danger_soon, danger_now = self._danger_tiles(grid, bombs, players)
        valid_actions = self._valid_actions(grid, my_pos, blocked)

        if my_pos in danger_now:
            escape = self._escape_action(grid, my_pos, blocked, danger_now, danger_soon)
            if escape is not None:
                return escape
            safe_moves = [a for a in valid_actions if self._next_pos(my_pos, a) not in danger_now]
            return random.choice(safe_moves) if safe_moves else 0

        closest_enemy_dist = min([abs(e[0] - my_pos[0]) + abs(e[1] - my_pos[1]) for e in enemies]) if enemies else float('inf')

        if bombs_left > 0 and my_pos not in bomb_positions:
            # Evaluate bomb placement with aggressive scoring
            bomb_score = self._evaluate_bomb_placement(grid, my_pos, enemies, bomb_radius, danger_soon)
            
            if bomb_score > 0 and self._can_escape_after_placing(grid, my_pos, blocked, danger_soon, bomb_radius):
                if closest_enemy_dist <= 4 or bomb_score > 3:
                    return 5

        if my_pos in danger_soon:
            escape = self._move_to_safe_tile(grid, my_pos, occupied, danger_soon, search_depth=8)
            if escape is not None:
                return escape

        # Aggressive enemy hunting when close
        if enemies:
            if closest_enemy_dist <= 7:
                move = self._hunt_enemy(grid, my_pos, enemies, occupied, danger_soon)
                if move is not None:
                    return move

        item_target = self._nearest_item(grid, my_pos, occupied, danger_soon)
        if item_target is not None:
            move = self._move_to_target(grid, my_pos, item_target, occupied, danger_soon)
            if move is not None:
                return move

        box_target = self._best_box_spot(grid, my_pos, occupied, danger_soon)
        if box_target is not None:
            move = self._move_to_target(grid, my_pos, box_target, occupied, danger_soon)
            if move is not None:
                return move

        safe_moves = [a for a in valid_actions if self._next_pos(my_pos, a) not in danger_soon]
        return random.choice(safe_moves) if safe_moves else 0

    def _next_pos(self, pos, action):
        dx, dy = self.MOVES[action]
        return pos[0] + dx, pos[1] + dy

    def _in_bounds(self, grid, x, y):
        return 0 <= x < grid.shape[0] and 0 <= y < grid.shape[1]

    def _passable(self, grid, x, y):
        return self._in_bounds(grid, x, y) and grid[x, y] in [0, 3, 4]

    def _valid_actions(self, grid, my_pos, occupied):
        actions = [0]
        for a in [1, 2, 3, 4]:
            nx, ny = self._next_pos(my_pos, a)
            if self._passable(grid, nx, ny) and (nx, ny) not in occupied:
                actions.append(a)
        return actions

    def _blast_tiles(self, grid, bx, by, radius):
        tiles = {(bx, by)}
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            for r in range(1, radius + 1):
                x, y = bx + dx * r, by + dy * r
                if not self._in_bounds(grid, x, y):
                    break
                cell = grid[x, y]
                if cell == 1:
                    break
                tiles.add((x, y))
                if cell == 2:
                    break
        return tiles

    def _danger_tiles(self, grid, bombs, players, default_radius=2):
        danger_soon = set()
        danger_now = set()
        for b in bombs:
            bx, by, timer = int(b[0]), int(b[1]), int(b[2])
            owner_id = int(b[3]) if len(b) > 3 else -1
            if timer <= 0:
                continue
            radius = default_radius
            if 0 <= owner_id < len(players):
                radius = max(1, int(players[owner_id][4]) + 1)
            blast = self._blast_tiles(grid, bx, by, radius)
            danger_soon |= blast
            if timer <= 1:
                danger_now |= blast
        return danger_soon, danger_now

    def _move_to_target(self, grid, start, target, occupied, danger_soon):
        q = deque([(start, None)])
        seen = {start}
        while q:
            pos, first_action = q.popleft()
            if pos == target and first_action is not None:
                return first_action
            for a in [1, 2, 3, 4]:
                nx, ny = self._next_pos(pos, a)
                npos = (nx, ny)
                if npos in seen or not self._passable(grid, nx, ny):
                    continue
                if npos in occupied or npos in danger_soon:
                    continue
                seen.add(npos)
                q.append((npos, a if first_action is None else first_action))
        return None

    def _nearest_item(self, grid, start, occupied, danger_soon):
        items = {(x, y) for x in range(grid.shape[0]) for y in range(grid.shape[1]) if grid[x, y] in [3, 4]}
        return self._nearest_target(grid, start, items, occupied, danger_soon)

    def _best_box_spot(self, grid, start, occupied, danger_soon):
        best_spot = None
        best_score = 0
        for x in range(grid.shape[0]):
            for y in range(grid.shape[1]):
                if grid[x, y] != 2:
                    continue
                for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    nx, ny = x + dx, y + dy
                    if not self._passable(grid, nx, ny) or (nx, ny) in occupied:
                        continue
                    score = self._count_boxes_in_blast(grid, (nx, ny), 2)
                    if score > best_score and self._is_reachable(grid, start, (nx, ny), occupied, danger_soon):
                        best_score = score
                        best_spot = (nx, ny)
        return best_spot

    def _hunt_enemy(self, grid, start, enemies, occupied, danger_soon):
        """Hunt closest enemy with tactical maneuvering"""
        q = deque([(start, None)])
        seen = {start}
        closest_dist = float('inf')
        best_actions = []
        
        while q:
            pos, first_action = q.popleft()
            for enemy in enemies:
                dist = abs(pos[0] - enemy[0]) + abs(pos[1] - enemy[1])
                if dist < closest_dist:
                    closest_dist = dist
                    best_actions = [first_action]
                elif dist == closest_dist and first_action not in best_actions:
                    best_actions.append(first_action)
            
            if closest_dist <= 2:
                break
            
            for a in [1, 2, 3, 4]:
                nx, ny = self._next_pos(pos, a)
                npos = (nx, ny)
                if npos in seen or not self._passable(grid, nx, ny):
                    continue
                if npos in occupied or npos in danger_soon:
                    continue
                seen.add(npos)
                q.append((npos, a if first_action is None else first_action))
        
        if best_actions:
            return random.choice([a for a in best_actions if a is not None]) if any(a is not None for a in best_actions) else best_actions[0]
        return None

    def _nearest_target(self, grid, start, targets, occupied, danger_soon):
        if not targets:
            return None
        q = deque([(start, None)])
        seen = {start}
        while q:
            pos, first_action = q.popleft()
            if pos in targets and first_action is not None:
                return first_action
            for a in [1, 2, 3, 4]:
                nx, ny = self._next_pos(pos, a)
                npos = (nx, ny)
                if npos in seen or not self._passable(grid, nx, ny):
                    continue
                if npos in occupied or npos in danger_soon:
                    continue
                seen.add(npos)
                q.append((npos, a if first_action is None else first_action))
        return None

    def _is_reachable(self, grid, start, target, occupied, danger_soon):
        q = deque([start])
        seen = {start}
        while q:
            pos = q.popleft()
            if pos == target:
                return True
            for a in [1, 2, 3, 4]:
                nx, ny = self._next_pos(pos, a)
                npos = (nx, ny)
                if npos in seen or not self._passable(grid, nx, ny):
                    continue
                if npos in occupied or npos in danger_soon:
                    continue
                seen.add(npos)
                q.append(npos)
        return False

    def _count_boxes_in_blast(self, grid, pos, radius):
        return sum(1 for x, y in self._blast_tiles(grid, pos[0], pos[1], radius) if grid[x, y] == 2)

    def _line_clear(self, grid, a, b):
        ax, ay = a
        bx, by = b
        if ax == bx:
            step = 1 if by > ay else -1
            for y in range(ay + step, by, step):
                if grid[ax, y] in [1, 2]:
                    return False
            return True
        if ay == by:
            step = 1 if bx > ax else -1
            for x in range(ax + step, bx, step):
                if grid[x, ay] in [1, 2]:
                    return False
            return True
        return False

    def _move_to_safe_tile(self, grid, start, occupied, danger, search_depth=8):
        q = deque([(start, None, 0)])
        seen = {start}
        while q:
            pos, first_action, depth = q.popleft()
            if pos not in danger and depth > 0:
                return first_action
            if depth >= search_depth:
                continue
            for a in [1, 2, 3, 4]:
                nx, ny = self._next_pos(pos, a)
                npos = (nx, ny)
                if npos in seen or not self._passable(grid, nx, ny) or npos in occupied:
                    continue
                seen.add(npos)
                q.append((npos, a if first_action is None else first_action, depth + 1))
        return None

    def _escape_action(self, grid, my_pos, occupied, danger_now, danger_soon):
        action = self._move_to_safe_tile(grid, my_pos, occupied, danger_now, search_depth=10)
        if action is not None:
            return action
        return self._move_to_safe_tile(grid, my_pos, occupied, danger_soon, search_depth=10)

    def _can_escape_after_placing(self, grid, my_pos, occupied, existing_danger, bomb_radius):
        my_blast = self._blast_tiles(grid, my_pos[0], my_pos[1], bomb_radius)
        combined_danger = set(existing_danger) | my_blast
        return self._move_to_safe_tile(grid, my_pos, occupied, combined_danger, search_depth=8) is not None

    def _minimax_bomb_score(self, grid, bomb_pos, enemies, radius, danger, occupied, depth=2, alpha=-float('inf'), beta=float('inf')):
        """Legacy minimax method"""
        return self._evaluate_bomb_placement(grid, bomb_pos, enemies, radius, danger)

    def _evaluate_bomb_placement(self, grid, bomb_pos, enemies, radius, danger):
        """Evaluate bomb placement value using heuristic scoring"""
        blast_tiles = self._blast_tiles(grid, bomb_pos[0], bomb_pos[1], radius)
        
        hit_boxes = sum(1 for x, y in blast_tiles if grid[x, y] == 2)
        hit_enemies = 0
        min_enemy_dist = float('inf')
        
        for ex, ey in enemies:
            if (ex, ey) in blast_tiles and self._line_clear(grid, bomb_pos, (ex, ey)):
                hit_enemies += 1
                min_enemy_dist = 0
            else:
                dist = abs(ex - bomb_pos[0]) + abs(ey - bomb_pos[1])
                min_enemy_dist = min(min_enemy_dist, dist)
        
        # Scoring: boxes worth 0.5, direct kills worth 8, close pressure worth bonus
        score = hit_boxes * 0.5 + hit_enemies * 8.0
        
        # Pressure bonus for close enemies
        if min_enemy_dist == 1:
            score += 4.0
        elif min_enemy_dist == 2:
            score += 2.0
        elif min_enemy_dist <= radius:
            score += 1.5
        
        return score

